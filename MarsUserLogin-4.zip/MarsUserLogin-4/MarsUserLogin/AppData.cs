﻿namespace MarsUserLogin {
    
    
    public partial class AppData {
    }
}

namespace MarsUserLogin.AppDataTableAdapters {
    
    
    public partial class TrajectoryTableAdapter {
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsUserLogin
{
    public partial class FrmAddEditsUsers : Form
    {
        public FrmAddEditsUsers()
        {
            InitializeComponent();
        }

        private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        {
           try
            {
            if (e.KeyCode == Keys.Delete)
                if (MessageBox.Show("Are you sure you want to delete this record ? ", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    usersBindingSource1.RemoveCurrent();
        }

        catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
   
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private void FrmAddEditsUsers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'appData.Users' table. You can move, or remove it, as needed.
            this.usersTableAdapter1.Fill(this.appData.Users);
            // TODO: This line of code loads data into the 'seniorProjectDataSet1.Users' table. You can move, or remove it, as needed.
           // this.usersTableAdapter1.Fill(this.seniorProjectDataSet1.Users);
            // TODO: This line of code loads data into the 'seniorProjectDataSet.Users' table. You can move, or remove it, as needed.
          //  this.usersTableAdapter.Fill(this.seniorProjectDataSet.Users);
         //   usersBindingSource.DataSource = this.seniorProjectDataSet.Users;
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            FrmAdmin openform = new FrmAdmin();
            openform.Show();
            Visible = false;
        }
       
    }
}

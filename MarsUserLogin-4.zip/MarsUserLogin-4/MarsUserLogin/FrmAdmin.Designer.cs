﻿namespace MarsUserLogin
{
    partial class FrmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAdmin));
            this.btmAccountControl = new System.Windows.Forms.Button();
            this.btmSensorV = new System.Windows.Forms.Button();
            this.lblAdminWelcome = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btmAccountControl
            // 
            this.btmAccountControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmAccountControl.Location = new System.Drawing.Point(508, 356);
            this.btmAccountControl.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btmAccountControl.Name = "btmAccountControl";
            this.btmAccountControl.Size = new System.Drawing.Size(233, 54);
            this.btmAccountControl.TabIndex = 0;
            this.btmAccountControl.Text = "AccountControl";
            this.btmAccountControl.UseVisualStyleBackColor = true;
            this.btmAccountControl.Click += new System.EventHandler(this.btmAccountControl_Click);
            // 
            // btmSensorV
            // 
            this.btmSensorV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmSensorV.Location = new System.Drawing.Point(508, 440);
            this.btmSensorV.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btmSensorV.Name = "btmSensorV";
            this.btmSensorV.Size = new System.Drawing.Size(233, 49);
            this.btmSensorV.TabIndex = 1;
            this.btmSensorV.Text = "SensorValues";
            this.btmSensorV.UseVisualStyleBackColor = true;
            this.btmSensorV.Click += new System.EventHandler(this.btmSensorV_Click);
            // 
            // lblAdminWelcome
            // 
            this.lblAdminWelcome.AutoSize = true;
            this.lblAdminWelcome.BackColor = System.Drawing.Color.LightSalmon;
            this.lblAdminWelcome.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblAdminWelcome.Location = new System.Drawing.Point(502, 71);
            this.lblAdminWelcome.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAdminWelcome.Name = "lblAdminWelcome";
            this.lblAdminWelcome.Size = new System.Drawing.Size(277, 38);
            this.lblAdminWelcome.TabIndex = 5;
            this.lblAdminWelcome.Text = "Welcome Back";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(90, 160);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(380, 329);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // FrmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(961, 646);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblAdminWelcome);
            this.Controls.Add(this.btmSensorV);
            this.Controls.Add(this.btmAccountControl);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "FrmAdmin";
            this.Text = "Admin";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmAdmin_FormClosed);
            this.Load += new System.EventHandler(this.FrmAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btmAccountControl;
        private System.Windows.Forms.Button btmSensorV;
        private System.Windows.Forms.Label lblAdminWelcome;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
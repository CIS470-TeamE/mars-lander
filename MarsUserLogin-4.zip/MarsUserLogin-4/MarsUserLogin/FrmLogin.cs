﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MarsUserLogin
{
    public partial class frmLogin : Form
    {

        private OleDbConnection connection = new OleDbConnection();
        public frmLogin()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Yimi\Documents\SeniorProject.accdb;
Persist Security Info=False;";
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            try
            {
                connection.Open();

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
                
            }
        }

        private void lblPassword_Click(object sender, EventArgs e)
        {

        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUserPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblUserName_Click(object sender, EventArgs e)
        {

        }


        private void btmAdmin_Click(object sender, EventArgs e)
        {
          
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "select * from Users where Username='"+ txtUserName.Text+ "'and Password='"+txtPassword.Text+ "'";
            OleDbDataReader reader = command.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count = count + 1;
            }
            if (count == 1)
            {
                FrmAdmin openform = new FrmAdmin();
                openform.Show();
                Visible = false;
            }
            else if (count>1)
            {
                MessageBox.Show("Duplicate Username and Password");
            
            }
 
            else
            {
                
                MessageBox.Show("Please check your UserName and password");
            }
            connection.Close();
        }
    }
}

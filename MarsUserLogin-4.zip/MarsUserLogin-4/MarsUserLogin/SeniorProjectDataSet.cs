﻿namespace MarsUserLogin {
    
    
    public partial class SeniorProjectDataSet {
        partial class UsersDataTable
        {
        }
    }
}

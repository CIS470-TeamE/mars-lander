﻿namespace MarsUserLogin
{
    partial class frmAccountControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAccountControl));
            this.btmAddUsers = new System.Windows.Forms.Button();
            this.pict4AccountControl = new System.Windows.Forms.PictureBox();
            this.btmPrevious = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pict4AccountControl)).BeginInit();
            this.SuspendLayout();
            // 
            // btmAddUsers
            // 
            this.btmAddUsers.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmAddUsers.Location = new System.Drawing.Point(407, 357);
            this.btmAddUsers.Name = "btmAddUsers";
            this.btmAddUsers.Size = new System.Drawing.Size(250, 57);
            this.btmAddUsers.TabIndex = 0;
            this.btmAddUsers.Text = "Add Users";
            this.btmAddUsers.UseVisualStyleBackColor = true;
            this.btmAddUsers.Click += new System.EventHandler(this.btmAddUsers_Click);
            // 
            // pict4AccountControl
            // 
            this.pict4AccountControl.Image = ((System.Drawing.Image)(resources.GetObject("pict4AccountControl.Image")));
            this.pict4AccountControl.Location = new System.Drawing.Point(39, 129);
            this.pict4AccountControl.Name = "pict4AccountControl";
            this.pict4AccountControl.Size = new System.Drawing.Size(299, 374);
            this.pict4AccountControl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pict4AccountControl.TabIndex = 2;
            this.pict4AccountControl.TabStop = false;
            // 
            // btmPrevious
            // 
            this.btmPrevious.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmPrevious.Location = new System.Drawing.Point(407, 446);
            this.btmPrevious.Name = "btmPrevious";
            this.btmPrevious.Size = new System.Drawing.Size(250, 57);
            this.btmPrevious.TabIndex = 3;
            this.btmPrevious.Text = "Previous";
            this.btmPrevious.UseVisualStyleBackColor = true;
            this.btmPrevious.Click += new System.EventHandler(this.btmPrevious_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(75, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 37);
            this.label1.TabIndex = 4;
            this.label1.Text = "Manage Users";
            // 
            // frmAccountControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(799, 534);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btmPrevious);
            this.Controls.Add(this.pict4AccountControl);
            this.Controls.Add(this.btmAddUsers);
            this.Name = "frmAccountControl";
            this.Text = "AccountControl";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmAccountControl_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pict4AccountControl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btmAddUsers;
        private System.Windows.Forms.PictureBox pict4AccountControl;
        private System.Windows.Forms.Button btmPrevious;
        private System.Windows.Forms.Label label1;
    }
}
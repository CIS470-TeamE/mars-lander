﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsUserLogin
{
    public partial class frmAccountControl : Form
    {
        public frmAccountControl()
        {
            InitializeComponent();
        }

        private void btmAddUsers_Click(object sender, EventArgs e)
        {
            //frmAddUser openform = new frmAddUser();
          //  openform.Show();
           // Visible = false;

        }

        private void btmPrevious_Click(object sender, EventArgs e)
        {
            FrmAdmin openform = new FrmAdmin();
            openform.Show();
            Visible = false;
        }

        private void frmAccountControl_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}

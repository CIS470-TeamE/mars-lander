﻿namespace MarsUserLogin
{
    partial class frmBeginMarsDecending
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnEnd = new System.Windows.Forms.Button();
            this.beginDecendingDB = new MarsUserLogin.BeginDecendingDB();
            this.trajectoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trajectoryTableAdapter = new MarsUserLogin.BeginDecendingDBTableAdapters.TrajectoryTableAdapter();
            this.trajectoryIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phase1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phase2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phase3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phase4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phase5DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.accelerometersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accelerometersTableAdapter = new MarsUserLogin.BeginDecendingDBTableAdapters.AccelerometersTableAdapter();
            this.accelerometerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accZDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.beginDecendingDB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trajectoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accelerometersBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.trajectoryIDDataGridViewTextBoxColumn,
            this.phase1DataGridViewTextBoxColumn,
            this.phase2DataGridViewTextBoxColumn,
            this.phase3DataGridViewTextBoxColumn,
            this.phase4DataGridViewTextBoxColumn,
            this.phase5DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.trajectoryBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(36, 669);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(484, 337);
            this.dataGridView1.TabIndex = 0;
            // 
            // btnEnd
            // 
            this.btnEnd.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnd.ForeColor = System.Drawing.Color.Blue;
            this.btnEnd.Location = new System.Drawing.Point(36, 588);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(134, 63);
            this.btnEnd.TabIndex = 1;
            this.btnEnd.Text = "End";
            this.btnEnd.UseVisualStyleBackColor = true;
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // beginDecendingDB
            // 
            this.beginDecendingDB.DataSetName = "BeginDecendingDB";
            this.beginDecendingDB.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // trajectoryBindingSource
            // 
            this.trajectoryBindingSource.DataMember = "Trajectory";
            this.trajectoryBindingSource.DataSource = this.beginDecendingDB;
            // 
            // trajectoryTableAdapter
            // 
            this.trajectoryTableAdapter.ClearBeforeFill = true;
            // 
            // trajectoryIDDataGridViewTextBoxColumn
            // 
            this.trajectoryIDDataGridViewTextBoxColumn.DataPropertyName = "TrajectoryID";
            this.trajectoryIDDataGridViewTextBoxColumn.HeaderText = "TrajectoryID";
            this.trajectoryIDDataGridViewTextBoxColumn.Name = "trajectoryIDDataGridViewTextBoxColumn";
            this.trajectoryIDDataGridViewTextBoxColumn.Width = 200;
            // 
            // phase1DataGridViewTextBoxColumn
            // 
            this.phase1DataGridViewTextBoxColumn.DataPropertyName = "Phase1";
            this.phase1DataGridViewTextBoxColumn.HeaderText = "Phase1";
            this.phase1DataGridViewTextBoxColumn.Name = "phase1DataGridViewTextBoxColumn";
            this.phase1DataGridViewTextBoxColumn.Width = 250;
            // 
            // phase2DataGridViewTextBoxColumn
            // 
            this.phase2DataGridViewTextBoxColumn.DataPropertyName = "Phase2";
            this.phase2DataGridViewTextBoxColumn.HeaderText = "Phase2";
            this.phase2DataGridViewTextBoxColumn.Name = "phase2DataGridViewTextBoxColumn";
            this.phase2DataGridViewTextBoxColumn.Width = 250;
            // 
            // phase3DataGridViewTextBoxColumn
            // 
            this.phase3DataGridViewTextBoxColumn.DataPropertyName = "Phase3";
            this.phase3DataGridViewTextBoxColumn.HeaderText = "Phase3";
            this.phase3DataGridViewTextBoxColumn.Name = "phase3DataGridViewTextBoxColumn";
            this.phase3DataGridViewTextBoxColumn.Width = 250;
            // 
            // phase4DataGridViewTextBoxColumn
            // 
            this.phase4DataGridViewTextBoxColumn.DataPropertyName = "Phase4";
            this.phase4DataGridViewTextBoxColumn.HeaderText = "Phase4";
            this.phase4DataGridViewTextBoxColumn.Name = "phase4DataGridViewTextBoxColumn";
            this.phase4DataGridViewTextBoxColumn.Width = 250;
            // 
            // phase5DataGridViewTextBoxColumn
            // 
            this.phase5DataGridViewTextBoxColumn.DataPropertyName = "phase5";
            this.phase5DataGridViewTextBoxColumn.HeaderText = "phase5";
            this.phase5DataGridViewTextBoxColumn.Name = "phase5DataGridViewTextBoxColumn";
            this.phase5DataGridViewTextBoxColumn.Width = 250;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.accelerometerIDDataGridViewTextBoxColumn,
            this.accXDataGridViewTextBoxColumn,
            this.accYDataGridViewTextBoxColumn,
            this.accZDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.accelerometersBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(526, 669);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(484, 337);
            this.dataGridView2.TabIndex = 2;
            // 
            // accelerometersBindingSource
            // 
            this.accelerometersBindingSource.DataMember = "Accelerometers";
            this.accelerometersBindingSource.DataSource = this.beginDecendingDB;
            // 
            // accelerometersTableAdapter
            // 
            this.accelerometersTableAdapter.ClearBeforeFill = true;
            // 
            // accelerometerIDDataGridViewTextBoxColumn
            // 
            this.accelerometerIDDataGridViewTextBoxColumn.DataPropertyName = "AccelerometerID";
            this.accelerometerIDDataGridViewTextBoxColumn.HeaderText = "AccelerometerID";
            this.accelerometerIDDataGridViewTextBoxColumn.Name = "accelerometerIDDataGridViewTextBoxColumn";
            this.accelerometerIDDataGridViewTextBoxColumn.Width = 250;
            // 
            // accXDataGridViewTextBoxColumn
            // 
            this.accXDataGridViewTextBoxColumn.DataPropertyName = "AccX";
            this.accXDataGridViewTextBoxColumn.HeaderText = "AccX";
            this.accXDataGridViewTextBoxColumn.Name = "accXDataGridViewTextBoxColumn";
            this.accXDataGridViewTextBoxColumn.Width = 200;
            // 
            // accYDataGridViewTextBoxColumn
            // 
            this.accYDataGridViewTextBoxColumn.DataPropertyName = "AccY";
            this.accYDataGridViewTextBoxColumn.HeaderText = "AccY";
            this.accYDataGridViewTextBoxColumn.Name = "accYDataGridViewTextBoxColumn";
            this.accYDataGridViewTextBoxColumn.Width = 200;
            // 
            // accZDataGridViewTextBoxColumn
            // 
            this.accZDataGridViewTextBoxColumn.DataPropertyName = "AccZ";
            this.accZDataGridViewTextBoxColumn.HeaderText = "AccZ";
            this.accZDataGridViewTextBoxColumn.Name = "accZDataGridViewTextBoxColumn";
            this.accZDataGridViewTextBoxColumn.Width = 200;
            // 
            // frmBeginMarsDecending
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MarsUserLogin.Properties.Resources.MarsLanding;
            this.ClientSize = new System.Drawing.Size(1629, 1038);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnEnd);
            this.Controls.Add(this.dataGridView1);
            this.Name = "frmBeginMarsDecending";
            this.Text = "BeginMarsDecending";
            this.Load += new System.EventHandler(this.frmBeginMarsDecending_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.beginDecendingDB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trajectoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accelerometersBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnEnd;
        private BeginDecendingDB beginDecendingDB;
        private System.Windows.Forms.BindingSource trajectoryBindingSource;
        private BeginDecendingDBTableAdapters.TrajectoryTableAdapter trajectoryTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn trajectoryIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phase1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phase2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phase3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phase4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phase5DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource accelerometersBindingSource;
        private BeginDecendingDBTableAdapters.AccelerometersTableAdapter accelerometersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn accelerometerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn accXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn accYDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn accZDataGridViewTextBoxColumn;
    }
}
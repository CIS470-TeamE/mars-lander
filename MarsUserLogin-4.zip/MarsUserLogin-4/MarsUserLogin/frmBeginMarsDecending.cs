﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsUserLogin
{
    public partial class frmBeginMarsDecending : Form
    {
        public frmBeginMarsDecending()
        {
            InitializeComponent();
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void frmBeginMarsDecending_Load(object sender, EventArgs e)
        {
           
            // TODO: This line of code loads data into the 'beginDecendingDB.Accelerometers' table. You can move, or remove it, as needed.
            this.accelerometersTableAdapter.Fill(this.beginDecendingDB.Accelerometers);
            // TODO: This line of code loads data into the 'beginDecendingDB.Trajectory' table. You can move, or remove it, as needed.
            this.trajectoryTableAdapter.Fill(this.beginDecendingDB.Trajectory);

        }
    }
}

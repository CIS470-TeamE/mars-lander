﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsUserLogin
{
    public partial class frmBeginMarsDecending : Form
    {
        public frmBeginMarsDecending()
        {
            InitializeComponent();
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmBeginMarsDecending_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'appData.Sensors' table. You can move, or remove it, as needed.
            this.sensorsTableAdapter.Fill(this.appData.Sensors);
            // TODO: This line of code loads data into the 'appData.Accelerometers' table. You can move, or remove it, as needed.
            this.accelerometersTableAdapter.Fill(this.appData.Accelerometers);
            // TODO: This line of code loads data into the 'appData.Trajectory' table. You can move, or remove it, as needed.
            this.trajectoryTableAdapter.Fill(this.appData.Trajectory);

        }
    }
}

﻿namespace MarsUserLogin
{
    partial class frmSensorValues
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.gyroscopesIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gyro1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gyro2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gyro3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gyroscopesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sensorData = new MarsUserLogin.SensorData();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblDoplerRadar = new System.Windows.Forms.Label();
            this.lblGyroscopes = new System.Windows.Forms.Label();
            this.lblAltimeter = new System.Windows.Forms.Label();
            this.lblAccelerometers = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.lblSensorControls = new System.Windows.Forms.Label();
            this.appData = new MarsUserLogin.AppData();
            this.gyroscopesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gyroscopesTableAdapter = new MarsUserLogin.AppDataTableAdapters.GyroscopesTableAdapter();
            this.seniorProjectDataSet = new MarsUserLogin.SeniorProjectDataSet();
            this.seniorProjectDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.usersTableAdapter = new MarsUserLogin.SeniorProjectDataSetTableAdapters.UsersTableAdapter();
            this.gyroscopesSensorsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sensorsTableAdapter = new MarsUserLogin.AppDataTableAdapters.SensorsTableAdapter();
            this.gyroscopesTableAdapter1 = new MarsUserLogin.SensorDataTableAdapters.GyroscopesTableAdapter();
            this.accelerometersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accelerometersTableAdapter = new MarsUserLogin.SensorDataTableAdapters.AccelerometersTableAdapter();
            this.accelerometerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accZDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dopplerRadarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dopplerRadarTableAdapter = new MarsUserLogin.SensorDataTableAdapters.DopplerRadarTableAdapter();
            this.dopplerRadarIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.readingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.altimeterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.altimeterTableAdapter = new MarsUserLogin.SensorDataTableAdapters.AltimeterTableAdapter();
            this.altimeterIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.altitudeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gyroscopesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sensorData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gyroscopesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seniorProjectDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seniorProjectDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gyroscopesSensorsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accelerometersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dopplerRadarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.altimeterBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.dataGridView4);
            this.panel1.Controls.Add(this.dataGridView3);
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.lblDoplerRadar);
            this.panel1.Controls.Add(this.lblGyroscopes);
            this.panel1.Controls.Add(this.lblAltimeter);
            this.panel1.Controls.Add(this.lblAccelerometers);
            this.panel1.Controls.Add(this.btnStart);
            this.panel1.Controls.Add(this.btnPrevious);
            this.panel1.Controls.Add(this.lblSensorControls);
            this.panel1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.panel1.Location = new System.Drawing.Point(33, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1773, 823);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dopplerRadarIDDataGridViewTextBoxColumn,
            this.readingDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.dopplerRadarBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(1257, 454);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 28;
            this.dataGridView4.Size = new System.Drawing.Size(489, 206);
            this.dataGridView4.TabIndex = 10;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gyroscopesIDDataGridViewTextBoxColumn,
            this.Gyro1,
            this.Gyro2,
            this.Gyro3});
            this.dataGridView3.DataSource = this.gyroscopesBindingSource1;
            this.dataGridView3.Location = new System.Drawing.Point(3, 453);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 28;
            this.dataGridView3.Size = new System.Drawing.Size(825, 206);
            this.dataGridView3.TabIndex = 9;
            // 
            // gyroscopesIDDataGridViewTextBoxColumn
            // 
            this.gyroscopesIDDataGridViewTextBoxColumn.DataPropertyName = "GyroscopesID";
            this.gyroscopesIDDataGridViewTextBoxColumn.HeaderText = "GyroscopesID";
            this.gyroscopesIDDataGridViewTextBoxColumn.Name = "gyroscopesIDDataGridViewTextBoxColumn";
            this.gyroscopesIDDataGridViewTextBoxColumn.Width = 200;
            // 
            // Gyro1
            // 
            this.Gyro1.DataPropertyName = "Gyro1";
            this.Gyro1.HeaderText = "Gyro1";
            this.Gyro1.Name = "Gyro1";
            this.Gyro1.Width = 150;
            // 
            // Gyro2
            // 
            this.Gyro2.DataPropertyName = "Gyro2";
            this.Gyro2.HeaderText = "Gyro2";
            this.Gyro2.Name = "Gyro2";
            this.Gyro2.Width = 150;
            // 
            // Gyro3
            // 
            this.Gyro3.DataPropertyName = "Gyro3";
            this.Gyro3.HeaderText = "Gyro3";
            this.Gyro3.Name = "Gyro3";
            this.Gyro3.Width = 150;
            // 
            // gyroscopesBindingSource1
            // 
            this.gyroscopesBindingSource1.DataMember = "Gyroscopes";
            this.gyroscopesBindingSource1.DataSource = this.sensorData;
            // 
            // sensorData
            // 
            this.sensorData.DataSetName = "SensorData";
            this.sensorData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.altimeterIDDataGridViewTextBoxColumn,
            this.altitudeDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.altimeterBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(1240, 103);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(506, 252);
            this.dataGridView2.TabIndex = 8;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.accelerometerIDDataGridViewTextBoxColumn,
            this.accXDataGridViewTextBoxColumn,
            this.accYDataGridViewTextBoxColumn,
            this.accZDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.accelerometersBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(3, 103);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(837, 252);
            this.dataGridView1.TabIndex = 7;
            // 
            // lblDoplerRadar
            // 
            this.lblDoplerRadar.AutoSize = true;
            this.lblDoplerRadar.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDoplerRadar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblDoplerRadar.Location = new System.Drawing.Point(1309, 382);
            this.lblDoplerRadar.Name = "lblDoplerRadar";
            this.lblDoplerRadar.Size = new System.Drawing.Size(274, 38);
            this.lblDoplerRadar.TabIndex = 6;
            this.lblDoplerRadar.Text = "Doppler Radar";
            // 
            // lblGyroscopes
            // 
            this.lblGyroscopes.AutoSize = true;
            this.lblGyroscopes.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGyroscopes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblGyroscopes.Location = new System.Drawing.Point(80, 372);
            this.lblGyroscopes.Name = "lblGyroscopes";
            this.lblGyroscopes.Size = new System.Drawing.Size(421, 38);
            this.lblGyroscopes.TabIndex = 5;
            this.lblGyroscopes.Text = "Gyroscopes Trajectory";
            // 
            // lblAltimeter
            // 
            this.lblAltimeter.AutoSize = true;
            this.lblAltimeter.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltimeter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblAltimeter.Location = new System.Drawing.Point(1358, 44);
            this.lblAltimeter.Name = "lblAltimeter";
            this.lblAltimeter.Size = new System.Drawing.Size(186, 38);
            this.lblAltimeter.TabIndex = 4;
            this.lblAltimeter.Text = "Altimeter";
            // 
            // lblAccelerometers
            // 
            this.lblAccelerometers.AutoSize = true;
            this.lblAccelerometers.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccelerometers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblAccelerometers.Location = new System.Drawing.Point(114, 44);
            this.lblAccelerometers.Name = "lblAccelerometers";
            this.lblAccelerometers.Size = new System.Drawing.Size(297, 38);
            this.lblAccelerometers.TabIndex = 3;
            this.lblAccelerometers.Text = "Accelerometers";
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnStart.Location = new System.Drawing.Point(1068, 623);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(162, 68);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnPrevious.Location = new System.Drawing.Point(880, 623);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(182, 69);
            this.btnPrevious.TabIndex = 1;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btmPrevious_Click);
            // 
            // lblSensorControls
            // 
            this.lblSensorControls.AccessibleDescription = "";
            this.lblSensorControls.AutoSize = true;
            this.lblSensorControls.BackColor = System.Drawing.Color.PaleTurquoise;
            this.lblSensorControls.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSensorControls.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblSensorControls.Location = new System.Drawing.Point(873, 11);
            this.lblSensorControls.Name = "lblSensorControls";
            this.lblSensorControls.Size = new System.Drawing.Size(303, 38);
            this.lblSensorControls.TabIndex = 0;
            this.lblSensorControls.Text = "Sensor Controls";
            this.lblSensorControls.Click += new System.EventHandler(this.lblSensorControls_Click);
            // 
            // appData
            // 
            this.appData.DataSetName = "AppData";
            this.appData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gyroscopesBindingSource
            // 
            this.gyroscopesBindingSource.DataMember = "Gyroscopes";
            this.gyroscopesBindingSource.DataSource = this.appData;
            // 
            // gyroscopesTableAdapter
            // 
            this.gyroscopesTableAdapter.ClearBeforeFill = true;
            // 
            // seniorProjectDataSet
            // 
            this.seniorProjectDataSet.DataSetName = "SeniorProjectDataSet";
            this.seniorProjectDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // seniorProjectDataSetBindingSource
            // 
            this.seniorProjectDataSetBindingSource.DataSource = this.seniorProjectDataSet;
            this.seniorProjectDataSetBindingSource.Position = 0;
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "Users";
            this.usersBindingSource.DataSource = this.seniorProjectDataSetBindingSource;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // gyroscopesSensorsBindingSource
            // 
            this.gyroscopesSensorsBindingSource.DataMember = "GyroscopesSensors";
            this.gyroscopesSensorsBindingSource.DataSource = this.gyroscopesBindingSource;
            // 
            // sensorsTableAdapter
            // 
            this.sensorsTableAdapter.ClearBeforeFill = true;
            // 
            // gyroscopesTableAdapter1
            // 
            this.gyroscopesTableAdapter1.ClearBeforeFill = true;
            // 
            // accelerometersBindingSource
            // 
            this.accelerometersBindingSource.DataMember = "Accelerometers";
            this.accelerometersBindingSource.DataSource = this.sensorData;
            // 
            // accelerometersTableAdapter
            // 
            this.accelerometersTableAdapter.ClearBeforeFill = true;
            // 
            // accelerometerIDDataGridViewTextBoxColumn
            // 
            this.accelerometerIDDataGridViewTextBoxColumn.DataPropertyName = "AccelerometerID";
            this.accelerometerIDDataGridViewTextBoxColumn.HeaderText = "AccelerometerID";
            this.accelerometerIDDataGridViewTextBoxColumn.Name = "accelerometerIDDataGridViewTextBoxColumn";
            this.accelerometerIDDataGridViewTextBoxColumn.Width = 250;
            // 
            // accXDataGridViewTextBoxColumn
            // 
            this.accXDataGridViewTextBoxColumn.DataPropertyName = "AccX";
            this.accXDataGridViewTextBoxColumn.HeaderText = "AccX";
            this.accXDataGridViewTextBoxColumn.Name = "accXDataGridViewTextBoxColumn";
            this.accXDataGridViewTextBoxColumn.Width = 150;
            // 
            // accYDataGridViewTextBoxColumn
            // 
            this.accYDataGridViewTextBoxColumn.DataPropertyName = "AccY";
            this.accYDataGridViewTextBoxColumn.HeaderText = "AccY";
            this.accYDataGridViewTextBoxColumn.Name = "accYDataGridViewTextBoxColumn";
            this.accYDataGridViewTextBoxColumn.Width = 150;
            // 
            // accZDataGridViewTextBoxColumn
            // 
            this.accZDataGridViewTextBoxColumn.DataPropertyName = "AccZ";
            this.accZDataGridViewTextBoxColumn.HeaderText = "AccZ";
            this.accZDataGridViewTextBoxColumn.Name = "accZDataGridViewTextBoxColumn";
            this.accZDataGridViewTextBoxColumn.Width = 150;
            // 
            // dopplerRadarBindingSource
            // 
            this.dopplerRadarBindingSource.DataMember = "DopplerRadar";
            this.dopplerRadarBindingSource.DataSource = this.sensorData;
            // 
            // dopplerRadarTableAdapter
            // 
            this.dopplerRadarTableAdapter.ClearBeforeFill = true;
            // 
            // dopplerRadarIDDataGridViewTextBoxColumn
            // 
            this.dopplerRadarIDDataGridViewTextBoxColumn.DataPropertyName = "DopplerRadarID";
            this.dopplerRadarIDDataGridViewTextBoxColumn.HeaderText = "DopplerRadarID";
            this.dopplerRadarIDDataGridViewTextBoxColumn.Name = "dopplerRadarIDDataGridViewTextBoxColumn";
            this.dopplerRadarIDDataGridViewTextBoxColumn.Width = 250;
            // 
            // readingDataGridViewTextBoxColumn
            // 
            this.readingDataGridViewTextBoxColumn.DataPropertyName = "Reading";
            this.readingDataGridViewTextBoxColumn.HeaderText = "Reading";
            this.readingDataGridViewTextBoxColumn.Name = "readingDataGridViewTextBoxColumn";
            this.readingDataGridViewTextBoxColumn.Width = 150;
            // 
            // altimeterBindingSource
            // 
            this.altimeterBindingSource.DataMember = "Altimeter";
            this.altimeterBindingSource.DataSource = this.sensorData;
            // 
            // altimeterTableAdapter
            // 
            this.altimeterTableAdapter.ClearBeforeFill = true;
            // 
            // altimeterIDDataGridViewTextBoxColumn
            // 
            this.altimeterIDDataGridViewTextBoxColumn.DataPropertyName = "AltimeterID";
            this.altimeterIDDataGridViewTextBoxColumn.HeaderText = "AltimeterID";
            this.altimeterIDDataGridViewTextBoxColumn.Name = "altimeterIDDataGridViewTextBoxColumn";
            this.altimeterIDDataGridViewTextBoxColumn.Width = 200;
            // 
            // altitudeDataGridViewTextBoxColumn
            // 
            this.altitudeDataGridViewTextBoxColumn.DataPropertyName = "Altitude";
            this.altitudeDataGridViewTextBoxColumn.HeaderText = "Altitude";
            this.altitudeDataGridViewTextBoxColumn.Name = "altitudeDataGridViewTextBoxColumn";
            this.altitudeDataGridViewTextBoxColumn.Width = 200;
            // 
            // frmSensorValues
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1826, 681);
            this.Controls.Add(this.panel1);
            this.Name = "frmSensorValues";
            this.Text = "frmSensorValues";
            this.Load += new System.EventHandler(this.frmSensorValues_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gyroscopesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sensorData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gyroscopesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seniorProjectDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seniorProjectDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gyroscopesSensorsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accelerometersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dopplerRadarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.altimeterBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSensorControls;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblDoplerRadar;
        private System.Windows.Forms.Label lblGyroscopes;
        private System.Windows.Forms.Label lblAltimeter;
        private System.Windows.Forms.Label lblAccelerometers;
        private System.Windows.Forms.Button btnStart;
        private AppData appData;
        private System.Windows.Forms.BindingSource gyroscopesBindingSource;
        private AppDataTableAdapters.GyroscopesTableAdapter gyroscopesTableAdapter;
        private System.Windows.Forms.BindingSource seniorProjectDataSetBindingSource;
        private SeniorProjectDataSet seniorProjectDataSet;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private SeniorProjectDataSetTableAdapters.UsersTableAdapter usersTableAdapter;
        private System.Windows.Forms.BindingSource gyroscopesSensorsBindingSource;
        private AppDataTableAdapters.SensorsTableAdapter sensorsTableAdapter;
        private SensorData sensorData;
        private System.Windows.Forms.BindingSource gyroscopesBindingSource1;
        private SensorDataTableAdapters.GyroscopesTableAdapter gyroscopesTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyroscopesIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gyro1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gyro2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gyro3;
        private System.Windows.Forms.BindingSource accelerometersBindingSource;
        private SensorDataTableAdapters.AccelerometersTableAdapter accelerometersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn accelerometerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn accXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn accYDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn accZDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource dopplerRadarBindingSource;
        private SensorDataTableAdapters.DopplerRadarTableAdapter dopplerRadarTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dopplerRadarIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn readingDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource altimeterBindingSource;
        private SensorDataTableAdapters.AltimeterTableAdapter altimeterTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn altimeterIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn altitudeDataGridViewTextBoxColumn;
    }
}
﻿namespace MarsUserLogin
{
    partial class frmSensorValues
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblEngineI = new System.Windows.Forms.Label();
            this.lblGyroscopes = new System.Windows.Forms.Label();
            this.lblActuator = new System.Windows.Forms.Label();
            this.lblAccelerometers = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.lblSensorControls = new System.Windows.Forms.Label();
            this.appData = new MarsUserLogin.AppData();
            this.appDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accelerometersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.accelerometersTableAdapter = new MarsUserLogin.AppDataTableAdapters.AccelerometersTableAdapter();
            this.gyroscopesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gyroscopesTableAdapter = new MarsUserLogin.AppDataTableAdapters.GyroscopesTableAdapter();
            this.gyroscopesIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gyro1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gyro2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gyro3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dopplerRadarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dopplerRadarTableAdapter = new MarsUserLogin.AppDataTableAdapters.DopplerRadarTableAdapter();
            this.seniorProjectDataSet = new MarsUserLogin.SeniorProjectDataSet();
            this.seniorProjectDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dopplerRadarIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.readingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accelerometersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gyroscopesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dopplerRadarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seniorProjectDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seniorProjectDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.dataGridView4);
            this.panel1.Controls.Add(this.dataGridView3);
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.lblEngineI);
            this.panel1.Controls.Add(this.lblGyroscopes);
            this.panel1.Controls.Add(this.lblActuator);
            this.panel1.Controls.Add(this.lblAccelerometers);
            this.panel1.Controls.Add(this.btnStart);
            this.panel1.Controls.Add(this.btnPrevious);
            this.panel1.Controls.Add(this.lblSensorControls);
            this.panel1.Font = new System.Drawing.Font("Verdana", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.panel1.Location = new System.Drawing.Point(33, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1773, 662);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.DataSource = this.seniorProjectDataSetBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(1316, 441);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 28;
            this.dataGridView4.Size = new System.Drawing.Size(415, 150);
            this.dataGridView4.TabIndex = 10;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gyroscopesIDDataGridViewTextBoxColumn,
            this.gyro1DataGridViewTextBoxColumn,
            this.gyro2DataGridViewTextBoxColumn,
            this.gyro3DataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.gyroscopesBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(87, 441);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 28;
            this.dataGridView3.Size = new System.Drawing.Size(470, 150);
            this.dataGridView3.TabIndex = 9;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(1316, 144);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(337, 150);
            this.dataGridView2.TabIndex = 8;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dopplerRadarIDDataGridViewTextBoxColumn,
            this.readingDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.dopplerRadarBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1773, 662);
            this.dataGridView1.TabIndex = 7;
            // 
            // lblEngineI
            // 
            this.lblEngineI.AutoSize = true;
            this.lblEngineI.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEngineI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblEngineI.Location = new System.Drawing.Point(1309, 354);
            this.lblEngineI.Name = "lblEngineI";
            this.lblEngineI.Size = new System.Drawing.Size(91, 38);
            this.lblEngineI.TabIndex = 6;
            this.lblEngineI.Text = "ewd";
            // 
            // lblGyroscopes
            // 
            this.lblGyroscopes.AutoSize = true;
            this.lblGyroscopes.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGyroscopes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblGyroscopes.Location = new System.Drawing.Point(80, 372);
            this.lblGyroscopes.Name = "lblGyroscopes";
            this.lblGyroscopes.Size = new System.Drawing.Size(421, 38);
            this.lblGyroscopes.TabIndex = 5;
            this.lblGyroscopes.Text = "Gyroscopes Trajectory";
            // 
            // lblActuator
            // 
            this.lblActuator.AutoSize = true;
            this.lblActuator.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActuator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblActuator.Location = new System.Drawing.Point(1309, 70);
            this.lblActuator.Name = "lblActuator";
            this.lblActuator.Size = new System.Drawing.Size(173, 38);
            this.lblActuator.TabIndex = 4;
            this.lblActuator.Text = "Actuator";
            // 
            // lblAccelerometers
            // 
            this.lblAccelerometers.AutoSize = true;
            this.lblAccelerometers.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccelerometers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblAccelerometers.Location = new System.Drawing.Point(80, 87);
            this.lblAccelerometers.Name = "lblAccelerometers";
            this.lblAccelerometers.Size = new System.Drawing.Size(297, 38);
            this.lblAccelerometers.TabIndex = 3;
            this.lblAccelerometers.Text = "Accelerometers";
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnStart.Location = new System.Drawing.Point(923, 523);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(162, 68);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnPrevious.Location = new System.Drawing.Point(712, 522);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(182, 69);
            this.btnPrevious.TabIndex = 1;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btmPrevious_Click);
            // 
            // lblSensorControls
            // 
            this.lblSensorControls.AccessibleDescription = "";
            this.lblSensorControls.AutoSize = true;
            this.lblSensorControls.BackColor = System.Drawing.Color.PaleTurquoise;
            this.lblSensorControls.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSensorControls.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblSensorControls.Location = new System.Drawing.Point(742, 24);
            this.lblSensorControls.Name = "lblSensorControls";
            this.lblSensorControls.Size = new System.Drawing.Size(303, 38);
            this.lblSensorControls.TabIndex = 0;
            this.lblSensorControls.Text = "Sensor Controls";
            this.lblSensorControls.Click += new System.EventHandler(this.lblSensorControls_Click);
            // 
            // appData
            // 
            this.appData.DataSetName = "AppData";
            this.appData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // appDataBindingSource
            // 
            this.appDataBindingSource.DataSource = this.appData;
            this.appDataBindingSource.Position = 0;
            // 
            // accelerometersBindingSource
            // 
            this.accelerometersBindingSource.DataMember = "Accelerometers";
            this.accelerometersBindingSource.DataSource = this.appData;
            // 
            // accelerometersTableAdapter
            // 
            this.accelerometersTableAdapter.ClearBeforeFill = true;
            // 
            // gyroscopesBindingSource
            // 
            this.gyroscopesBindingSource.DataMember = "Gyroscopes";
            this.gyroscopesBindingSource.DataSource = this.appData;
            // 
            // gyroscopesTableAdapter
            // 
            this.gyroscopesTableAdapter.ClearBeforeFill = true;
            // 
            // gyroscopesIDDataGridViewTextBoxColumn
            // 
            this.gyroscopesIDDataGridViewTextBoxColumn.DataPropertyName = "GyroscopesID";
            this.gyroscopesIDDataGridViewTextBoxColumn.HeaderText = "GyroscopesID";
            this.gyroscopesIDDataGridViewTextBoxColumn.Name = "gyroscopesIDDataGridViewTextBoxColumn";
            // 
            // gyro1DataGridViewTextBoxColumn
            // 
            this.gyro1DataGridViewTextBoxColumn.DataPropertyName = "Gyro1";
            this.gyro1DataGridViewTextBoxColumn.HeaderText = "Gyro1";
            this.gyro1DataGridViewTextBoxColumn.Name = "gyro1DataGridViewTextBoxColumn";
            // 
            // gyro2DataGridViewTextBoxColumn
            // 
            this.gyro2DataGridViewTextBoxColumn.DataPropertyName = "Gyro2";
            this.gyro2DataGridViewTextBoxColumn.HeaderText = "Gyro2";
            this.gyro2DataGridViewTextBoxColumn.Name = "gyro2DataGridViewTextBoxColumn";
            // 
            // gyro3DataGridViewTextBoxColumn
            // 
            this.gyro3DataGridViewTextBoxColumn.DataPropertyName = "Gyro3";
            this.gyro3DataGridViewTextBoxColumn.HeaderText = "Gyro3";
            this.gyro3DataGridViewTextBoxColumn.Name = "gyro3DataGridViewTextBoxColumn";
            // 
            // dopplerRadarBindingSource
            // 
            this.dopplerRadarBindingSource.DataMember = "DopplerRadar";
            this.dopplerRadarBindingSource.DataSource = this.appData;
            // 
            // dopplerRadarTableAdapter
            // 
            this.dopplerRadarTableAdapter.ClearBeforeFill = true;
            // 
            // seniorProjectDataSet
            // 
            this.seniorProjectDataSet.DataSetName = "SeniorProjectDataSet";
            this.seniorProjectDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // seniorProjectDataSetBindingSource
            // 
            this.seniorProjectDataSetBindingSource.DataSource = this.seniorProjectDataSet;
            this.seniorProjectDataSetBindingSource.Position = 0;
            // 
            // dopplerRadarIDDataGridViewTextBoxColumn
            // 
            this.dopplerRadarIDDataGridViewTextBoxColumn.DataPropertyName = "DopplerRadarID";
            this.dopplerRadarIDDataGridViewTextBoxColumn.HeaderText = "DopplerRadarID";
            this.dopplerRadarIDDataGridViewTextBoxColumn.Name = "dopplerRadarIDDataGridViewTextBoxColumn";
            this.dopplerRadarIDDataGridViewTextBoxColumn.Width = 210;
            // 
            // readingDataGridViewTextBoxColumn
            // 
            this.readingDataGridViewTextBoxColumn.DataPropertyName = "Reading";
            this.readingDataGridViewTextBoxColumn.HeaderText = "Reading";
            this.readingDataGridViewTextBoxColumn.Name = "readingDataGridViewTextBoxColumn";
            this.readingDataGridViewTextBoxColumn.Width = 150;
            // 
            // frmSensorValues
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1826, 681);
            this.Controls.Add(this.panel1);
            this.Name = "frmSensorValues";
            this.Text = "frmSensorValues";
            this.Load += new System.EventHandler(this.frmSensorValues_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accelerometersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gyroscopesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dopplerRadarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seniorProjectDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seniorProjectDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSensorControls;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblEngineI;
        private System.Windows.Forms.Label lblGyroscopes;
        private System.Windows.Forms.Label lblActuator;
        private System.Windows.Forms.Label lblAccelerometers;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.BindingSource appDataBindingSource;
        private AppData appData;
        private System.Windows.Forms.BindingSource accelerometersBindingSource;
        private AppDataTableAdapters.AccelerometersTableAdapter accelerometersTableAdapter;
        private System.Windows.Forms.BindingSource gyroscopesBindingSource;
        private AppDataTableAdapters.GyroscopesTableAdapter gyroscopesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyroscopesIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyro1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyro2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyro3DataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource dopplerRadarBindingSource;
        private AppDataTableAdapters.DopplerRadarTableAdapter dopplerRadarTableAdapter;
        private System.Windows.Forms.BindingSource seniorProjectDataSetBindingSource;
        private SeniorProjectDataSet seniorProjectDataSet;
        private System.Windows.Forms.DataGridViewTextBoxColumn dopplerRadarIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn readingDataGridViewTextBoxColumn;
    }
}
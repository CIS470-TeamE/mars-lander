﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsUserLogin
{
    public partial class frmSensorValues : Form
    {
        public frmSensorValues()
        {
            InitializeComponent();
        }

        private void btmPrevious_Click(object sender, EventArgs e)
        {
            FrmAdmin openform = new FrmAdmin();
            openform.Show();
            Visible = false;

        }

        private void lblSensorControls_Click(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            frmBeginMarsDecending openform = new frmBeginMarsDecending();
            openform.Show();
            Visible = false;
        }

        private void frmSensorValues_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sensorData.Altimeter' table. You can move, or remove it, as needed.
            this.altimeterTableAdapter.Fill(this.sensorData.Altimeter);
            // TODO: This line of code loads data into the 'sensorData.DopplerRadar' table. You can move, or remove it, as needed.
            this.dopplerRadarTableAdapter.Fill(this.sensorData.DopplerRadar);
            // TODO: This line of code loads data into the 'sensorData.Accelerometers' table. You can move, or remove it, as needed.
            this.accelerometersTableAdapter.Fill(this.sensorData.Accelerometers);
            // TODO: This line of code loads data into the 'sensorData.Gyroscopes' table. You can move, or remove it, as needed.
            this.gyroscopesTableAdapter1.Fill(this.sensorData.Gyroscopes);
            // TODO: This line of code loads data into the 'appData.Sensors' table. You can move, or remove it, as needed.
            this.sensorsTableAdapter.Fill(this.appData.Sensors);
            // TODO: This line of code loads data into the 'seniorProjectDataSet.Users' table. You can move, or remove it, as needed.
            //this.usersTableAdapter.Fill(this.seniorProjectDataSet.Users);
            // TODO: This line of code loads data into the 'appData.Gyroscopes' table. You can move, or remove it, as needed.
           // this.gyroscopesTableAdapter.Fill(this.appData.Gyroscopes);

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
           
        }
    }
}

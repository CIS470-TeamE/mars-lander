﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsUserLogin
{
    public partial class frmSensorValues : Form
    {
        public frmSensorValues()
        {
            InitializeComponent();
        }

        private void btmPrevious_Click(object sender, EventArgs e)
        {
            FrmAdmin openform = new FrmAdmin();
            openform.Show();
            Visible = false;

        }

        private void lblSensorControls_Click(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            frmBeginMarsDecending openform = new frmBeginMarsDecending();
            openform.Show();
            Visible = false;
        }

        private void frmSensorValues_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'appData.DopplerRadar' table. You can move, or remove it, as needed.
            this.dopplerRadarTableAdapter.Fill(this.appData.DopplerRadar);
            // TODO: This line of code loads data into the 'appData.Gyroscopes' table. You can move, or remove it, as needed.
            this.gyroscopesTableAdapter.Fill(this.appData.Gyroscopes);
            // TODO: This line of code loads data into the 'appData.Accelerometers' table. You can move, or remove it, as needed.
            this.accelerometersTableAdapter.Fill(this.appData.Accelerometers);

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

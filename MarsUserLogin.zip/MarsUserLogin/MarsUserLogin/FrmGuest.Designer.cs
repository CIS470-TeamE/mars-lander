﻿namespace MarsUserLogin
{
    partial class FrmGuest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGuest = new System.Windows.Forms.Label();
            this.btmDefaultSensorValues = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblGuest
            // 
            this.lblGuest.AutoSize = true;
            this.lblGuest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lblGuest.Font = new System.Drawing.Font("Verdana", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuest.Location = new System.Drawing.Point(49, 44);
            this.lblGuest.Name = "lblGuest";
            this.lblGuest.Size = new System.Drawing.Size(452, 26);
            this.lblGuest.TabIndex = 0;
            this.lblGuest.Text = "Welcome to the guest environment";
            // 
            // btmDefaultSensorValues
            // 
            this.btmDefaultSensorValues.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btmDefaultSensorValues.Font = new System.Drawing.Font("Verdana", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmDefaultSensorValues.Location = new System.Drawing.Point(343, 192);
            this.btmDefaultSensorValues.Name = "btmDefaultSensorValues";
            this.btmDefaultSensorValues.Size = new System.Drawing.Size(148, 66);
            this.btmDefaultSensorValues.TabIndex = 1;
            this.btmDefaultSensorValues.Text = "DefaultSensorValues";
            this.btmDefaultSensorValues.UseVisualStyleBackColor = false;
            this.btmDefaultSensorValues.Click += new System.EventHandler(this.btmDefaultSensorValues_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MarsUserLogin.Properties.Resources.Mars;
            this.pictureBox1.Location = new System.Drawing.Point(40, 110);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(287, 215);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // FrmGuest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(563, 395);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btmDefaultSensorValues);
            this.Controls.Add(this.lblGuest);
            this.Name = "FrmGuest";
            this.Text = "Guest";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGuest;
        private System.Windows.Forms.Button btmDefaultSensorValues;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace MarsUserLogin
{
    public partial class frmAddUser : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        public frmAddUser()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Yimi\Documents\SeniorProject.accdb;
Persist Security Info=False;";
            // Source=C:\Users\Yimi\Documents\SeniorProject.accdb this is the locatinof the database in your system// click the database then go to properties and copy the location
        }

        private void btmCancel_Click(object sender, EventArgs e)
        {
            frmAccountControl openform = new frmAccountControl();
            openform.Show();
            Visible = false;

        }

        private void frmAddUser_Load(object sender, EventArgs e)
        {
             try
            {
                connection.Open();

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void frmAddUser_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
        
        private void btmSubmit_Click(object sender, EventArgs e)
        {

            try
            {

                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "insert into Users (FirstName,LastName,EmployeeID) Values ('" + txtFirstName.Text + "', '" + txtLastName.Text + "','" + txtEmployeeID.Text + "') ";

                command.ExecuteNonQuery();
                MessageBox.Show("Data Successfully Saved");
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            }
    }
}

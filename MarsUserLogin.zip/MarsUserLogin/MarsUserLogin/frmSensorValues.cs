﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarsUserLogin
{
    public partial class frmSensorValues : Form
    {
        public frmSensorValues()
        {
            InitializeComponent();
        }

        private void btmPrevious_Click(object sender, EventArgs e)
        {
            FrmAdmin openform = new FrmAdmin();
            openform.Show();
            Visible = false;

        }
    }
}
